import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Germán Baher — Branding Consultant",
  description:
    "Brand strategist and creative director. I build brands from the inside out — clarity, identity and human connection. Ottawa, Canada.",
  openGraph: {
    title: "Germán Baher — Branding Consultant",
    description: "Strategy before aesthetics.",
    siteName: "Germán Baher",
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
