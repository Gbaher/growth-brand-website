"use client";

import Nav       from "@/components/layout/Nav";
import Footer    from "@/components/layout/Footer";
import Cursor    from "@/components/ui/Cursor";
import Marquee   from "@/components/ui/Marquee";
import Contact   from "@/components/ui/Contact";
import Hero        from "@/components/sections/Hero";
import Problem     from "@/components/sections/Problem";
import Methodology from "@/components/sections/Methodology";
import Cases       from "@/components/sections/Cases";
import Process     from "@/components/sections/Process";
import CTA         from "@/components/sections/CTA";

export default function Home() {
  return (
    <>
      <Cursor />
      <Nav />

      <main>
        {/* 1. Hero — branding consultant, creativity, strategy, design */}
        <Hero />

        {/* Marquee strip */}
        <Marquee />

        {/* 2. Problem — brands look good but don't connect */}
        <Problem />

        {/* 3. Methodology — Feeling, Doing, Thinking */}
        <Methodology />

        {/* 4. Cases — branding, retail, nonprofit, fitness, tourism */}
        <Cases />

        {/* 5. Process — diagnosis, strategy, visual system, guided implementation */}
        <Process />

        {/* 6. CTA — book a brand diagnosis */}
        <CTA />

        {/* Contact row */}
        <Contact />
      </main>

      <Footer />
    </>
  );
}
