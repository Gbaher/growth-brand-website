"use client";
import { useEffect, useRef } from "react";
import { revealUp } from "@/lib/animations";

export default function Footer() {
  const ref = useRef<HTMLElement>(null);

  useEffect(() => {
    if (!ref.current) return;
    revealUp(ref.current.querySelectorAll(".rv"), { trigger: ref.current, stagger: 0.08 });
  }, []);

  return (
    <footer
      ref={ref}
      className="relative z-10 border-t border-[var(--border)] px-16 py-9 flex items-center
        justify-between gap-6 flex-wrap"
      style={{ padding: "36px 64px" }}
    >
      <div>
        <div className="rv font-condensed font-bold text-sm tracking-[0.14em] uppercase text-ink/20">
          Germán Baher · Branding Consultant
        </div>
        <div className="rv text-[10px] tracking-[0.1em] uppercase text-ink/10 mt-1.5">
          German Baher LLC · Registered in Wyoming, USA
        </div>
      </div>
      <div className="rv text-right">
        <div className="text-[10px] tracking-[0.12em] uppercase text-ink/15">
          © 2026 · Ottawa, Canada · germanbaher.com
        </div>
        <div className="text-[10px] text-ink/10 mt-1 leading-relaxed">
          30 N Gould St Ste N · Sheridan, WY 82801, USA
        </div>
      </div>
    </footer>
  );
}
