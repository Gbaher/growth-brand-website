"use client";
import { useEffect, useRef, useState } from "react";
import { gsap } from "gsap";

const links = [
  { label: "Method",   href: "#methodology" },
  { label: "Work",     href: "#cases" },
  { label: "Process",  href: "#process" },
  { label: "Services", href: "#services" },
];

export default function Nav() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const navRef = useRef<HTMLElement>(null);

  // Entrance animation
  useEffect(() => {
    if (!navRef.current) return;
    gsap.fromTo(
      navRef.current,
      { opacity: 0, y: -12 },
      { opacity: 1, y: 0, duration: 0.8, ease: "power3.out", delay: 0.3 }
    );
  }, []);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 60);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <>
      <nav
        ref={navRef}
        className={`fixed top-0 left-0 right-0 z-[200] flex items-center justify-between
          px-16 h-[68px] transition-all duration-500 opacity-0
          ${scrolled ? "bg-black/90 backdrop-blur-lg border-b border-[var(--border)]" : ""}`}
        style={{ padding: "0 64px" }}
      >
        {/* Logo */}
        <a href="#" className="flex items-center flex-shrink-0">
          {/* Use your SVG logo here */}
          <span className="font-condensed font-bold text-sm tracking-[0.14em] uppercase text-ink leading-none">
            Germán Baher
            <span className="block text-[9px] tracking-[0.2em] text-[var(--ink-40)] font-normal mt-0.5">
              Branding Consultant
            </span>
          </span>
        </a>

        {/* Desktop links */}
        <ul className="hidden md:flex items-center gap-8 list-none">
          {links.map((l) => (
            <li key={l.href}>
              <a
                href={l.href}
                className="font-sans text-[11px] tracking-[0.16em] uppercase text-[var(--ink-60)]
                  hover:text-ink transition-colors duration-300 no-underline"
              >
                {l.label}
              </a>
            </li>
          ))}
        </ul>

        {/* CTA */}
        <a
          href="#cta"
          className="hidden md:inline-flex items-center gap-2 text-[11px] tracking-[0.16em]
            uppercase bg-[var(--cr)] text-white px-5 py-2.5 rounded-sm
            hover:bg-[var(--cr2)] transition-colors duration-300 no-underline font-sans font-medium"
        >
          Book a Diagnosis
        </a>

        {/* Mobile hamburger */}
        <button
          className="md:hidden flex flex-col gap-1.5 w-5 text-ink"
          onClick={() => setMobileOpen(!mobileOpen)}
          aria-label="Toggle menu"
        >
          <span
            className={`h-px bg-current transition-all duration-300 ${
              mobileOpen ? "rotate-45 translate-y-2" : ""
            }`}
          />
          <span
            className={`h-px bg-current transition-all duration-300 ${
              mobileOpen ? "opacity-0" : ""
            }`}
          />
          <span
            className={`h-px bg-current transition-all duration-300 ${
              mobileOpen ? "-rotate-45 -translate-y-2" : ""
            }`}
          />
        </button>
      </nav>

      {/* Mobile menu */}
      {mobileOpen && (
        <div className="fixed inset-0 z-[150] bg-black flex flex-col items-center justify-center gap-10 md:hidden">
          {links.map((l) => (
            <a
              key={l.href}
              href={l.href}
              onClick={() => setMobileOpen(false)}
              className="font-condensed font-bold text-5xl text-ink hover:text-[var(--cr)] transition-colors no-underline"
            >
              {l.label}
            </a>
          ))}
          <a
            href="#cta"
            onClick={() => setMobileOpen(false)}
            className="font-condensed font-bold text-5xl text-[var(--cr)] no-underline"
          >
            Book a Diagnosis
          </a>
        </div>
      )}
    </>
  );
}
