"use client";
import { useEffect, useRef } from "react";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { revealUp, prefersReducedMotion } from "@/lib/animations";

const questions = [
  "Does my brand actually connect with people?",
  "Do we know what we stand for beyond our product?",
  "Are we communicating consistently across touchpoints?",
  "Do we have a real strategy — or are we just producing content?",
];

export default function CTA() {
  const sectionRef = useRef<HTMLElement>(null);
  const innerRef   = useRef<HTMLDivElement>(null);
  const scaleRef   = useRef<HTMLDivElement>(null);

  useEffect(() => {
    gsap.registerPlugin(ScrollTrigger);
    const section = sectionRef.current;
    if (!section || prefersReducedMotion()) return;

    // Section scales up on scroll enter
    gsap.fromTo(
      scaleRef.current,
      { scale: 0.97, opacity: 0 },
      {
        scale: 1,
        opacity: 1,
        duration: 0.9,
        ease: "power3.out",
        scrollTrigger: {
          trigger: section,
          start: "top 75%",
          toggleActions: "play none none reverse",
        },
      }
    );

    // Inner content
    if (innerRef.current) {
      revealUp(innerRef.current.querySelectorAll(".rv"), {
        trigger: section,
        stagger: 0.1,
        start: "top 70%",
      });
    }
  }, []);

  return (
    <section
      ref={sectionRef}
      id="cta"
      className="relative z-10 overflow-hidden"
      style={{ padding: "120px 64px" }}
    >
      <div ref={scaleRef} className="relative">
        {/* Background — full crimson with dark overlay */}
        <div
          className="absolute inset-0 rounded-sm"
          style={{ background: "var(--cr)" }}
        />
        {/* CTA bg image overlay if available */}
        {/* <Image src="/assets/cta/cta-background-dark.webp" alt="" fill className="object-cover opacity-30 rounded-sm mix-blend-multiply" /> */}

        {/* Ghost text */}
        <div
          className="absolute inset-0 overflow-hidden flex items-center justify-center
            pointer-events-none rounded-sm"
          aria-hidden
        >
          <span
            className="font-condensed font-bold italic select-none"
            style={{
              fontSize: "clamp(90px, 18vw, 240px)",
              color: "rgba(255,255,255,.05)",
              letterSpacing: "-0.03em",
              whiteSpace: "nowrap",
            }}
          >
            CLARITY
          </span>
        </div>

        {/* Content */}
        <div
          ref={innerRef}
          className="relative z-10 text-center"
          style={{ padding: "100px 64px" }}
        >
          <p className="rv text-[10px] tracking-[0.22em] uppercase text-white/50 mb-7">
            07 · Book a brand diagnosis
          </p>

          <h2
            className="rv font-condensed font-bold text-white leading-[0.92] mb-8"
            style={{
              fontSize: "clamp(44px, 7vw, 100px)",
              letterSpacing: "-0.025em",
              maxWidth: "760px",
              margin: "0 auto 28px",
            }}
          >
            Your brand does not need more content.
            <br />
            It needs{" "}
            <em className="italic underline underline-offset-4 decoration-white/30">
              direction.
            </em>
          </h2>

          {/* Self-audit questions */}
          <div
            className="rv grid sm:grid-cols-2 gap-3 mb-12 text-left"
            style={{ maxWidth: "680px", margin: "0 auto 48px" }}
          >
            {questions.map((q, i) => (
              <div
                key={i}
                className="flex items-start gap-3 bg-white/10 rounded-sm px-4 py-3"
              >
                <div className="w-1 h-1 rounded-full bg-white/50 flex-shrink-0 mt-2" />
                <p className="font-light text-white/75 text-sm leading-relaxed">{q}</p>
              </div>
            ))}
          </div>

          {/* Primary CTA */}
          <a
            href="mailto:hola@germanbaher.com"
            className="rv inline-flex items-center gap-3 bg-white text-[var(--cr)] rounded-sm
              font-sans font-semibold text-[12px] tracking-[0.18em] uppercase px-10 py-4
              hover:bg-white/90 transition-all duration-300 no-underline"
            style={{ display: "inline-flex" }}
          >
            Book a 30-min Brand Diagnosis
            <svg width="16" height="10" viewBox="0 0 16 10" fill="none">
              <path d="M0 5h14M10 1l4 4-4 4" stroke="currentColor" strokeWidth="1"
                strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </a>

          <p className="rv text-[10px] tracking-[0.14em] uppercase text-white/30 mt-4">
            No commitment · 30 minutes · Real clarity
          </p>
        </div>
      </div>
    </section>
  );
}
