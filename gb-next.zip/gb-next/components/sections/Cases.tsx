"use client";
import { useEffect, useRef, useState } from "react";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { revealUp, prefersReducedMotion } from "@/lib/animations";

const cases = [
  {
    id:       "pil",
    num:      "01",
    name:     "Bodega PIL",
    category: "Retail Branding · Visual Identity",
    country:  "Bolivia",
    color:    "#961a34",
    summary:
      "Category architecture and strategic communication. Clear categorization, actionable messaging and stronger visual hierarchy improved clarity for customers and internal teams alike.",
    result:
      "A system that made communication structured and decision-making faster — not just better packaging.",
  },
  {
    id:       "sofia",
    num:      "02",
    name:     "Sofía al Paso",
    category: "Shopper Marketing · Brand Experience",
    country:  "Bolivia",
    color:    "#1a2535",
    summary:
      "Shopper marketing aligned with a more human brand experience. The brand began communicating convenience, warmth and everyday connection — not just products.",
    result:
      "Clearer brand experience, stronger emotional presence in retail, better alignment between strategy and execution.",
  },
  {
    id:       "alalay",
    num:      "03",
    name:     "Fundación Alalay",
    category: "Purpose Brand · Nonprofit Storytelling",
    country:  "Bolivia",
    color:    "#1a3520",
    summary:
      "Brand transformation based on the Feeling Doing Thinking methodology. The goal: move beyond institutional communication toward a human narrative centered on dignity, resilience and opportunity.",
    result:
      "A brand identity that speaks to people — not just donors or institutions.",
  },
  {
    id:       "becycle",
    num:      "04",
    name:     "Be Cycle",
    category: "Fitness Brand · Visual Systems",
    country:  "Bolivia",
    color:    "#2a1a4e",
    summary:
      "A premium fitness brand built around a cinematic dark aesthetic and a bold visual identity designed for a new generation of riders.",
    result:
      "A brand positioned as a premium, aspirational choice in a commoditized fitness category.",
  },
  {
    id:       "bno",
    num:      "05",
    name:     "Business Network Ottawa",
    category: "Brand System · Visual Identity",
    country:  "Canada",
    color:    "#0c1a35",
    summary:
      "A complete brand system for one of Ottawa's most active professional networks — built to reflect strategic clarity, community leadership and growth.",
    result:
      "A cohesive identity that elevated the organization's presence across events, digital and print.",
  },
];

function CaseRow({ c, index }: { c: typeof cases[0]; index: number }) {
  const [open, setOpen] = useState(false);
  const rowRef    = useRef<HTMLDivElement>(null);
  const expandRef = useRef<HTMLDivElement>(null);

  // Expand / collapse with GSAP
  const toggle = () => {
    const expand = expandRef.current;
    if (!expand) return;
    if (!open) {
      gsap.fromTo(expand, { height: 0, opacity: 0 }, { height: "auto", opacity: 1, duration: 0.5, ease: "power3.out" });
    } else {
      gsap.to(expand, { height: 0, opacity: 0, duration: 0.4, ease: "power3.in" });
    }
    setOpen(!open);
  };

  useEffect(() => {
    if (!rowRef.current) return;
    gsap.registerPlugin(ScrollTrigger);
    revealUp(rowRef.current, {
      trigger: rowRef.current,
      delay: index * 0.06,
      start: "top 88%",
    });
  }, [index]);

  return (
    <div ref={rowRef} className="border-b border-[var(--border)] cursor-pointer" onClick={toggle}>
      {/* Header */}
      <div
        className="flex items-center justify-between py-6 gap-5 transition-all duration-400"
        style={{ paddingLeft: open ? "14px" : "0", transition: "padding-left .4s" }}
      >
        <div className="flex items-baseline gap-5">
          <span
            className="font-condensed font-bold text-5xl leading-none min-w-[48px] transition-colors duration-300"
            style={{ color: open ? "rgba(238,37,81,.22)" : "rgba(238,37,81,.06)" }}
          >
            {c.num}
          </span>
          <div>
            <div
              className="font-condensed font-bold leading-none transition-colors duration-300"
              style={{
                fontSize: "clamp(22px, 3vw, 30px)",
                letterSpacing: "-0.01em",
                color: open ? "var(--cr)" : "var(--ink)",
              }}
            >
              {c.name}
            </div>
            <div className="text-[10px] tracking-[0.12em] uppercase text-[var(--ink-40)] mt-1.5">
              {c.category} · {c.country}
            </div>
          </div>
        </div>
        <div
          className="w-8 h-8 flex items-center justify-center border border-[var(--border)]
            transition-all duration-300 text-[var(--ink-40)] flex-shrink-0"
          style={{
            borderColor: open ? "var(--cr)" : undefined,
            color:       open ? "var(--cr)" : undefined,
            transform:   open ? "rotate(45deg)" : undefined,
          }}
        >
          <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
            <path d="M6 1v10M1 6h10" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" />
          </svg>
        </div>
      </div>

      {/* Expand */}
      <div ref={expandRef} className="overflow-hidden" style={{ height: 0, opacity: 0 }}>
        <div className="pb-8 grid md:grid-cols-2 gap-6">
          {/* Color block */}
          <div
            className="rounded-sm p-7 flex flex-col justify-between"
            style={{ background: c.color, minHeight: "180px" }}
          >
            <p className="text-[10px] tracking-[0.18em] uppercase text-white/40 mb-3">
              The project
            </p>
            <p className="font-light text-white/75 leading-relaxed" style={{ fontSize: "17px" }}>
              {c.summary}
            </p>
          </div>
          {/* Result */}
          <div
            className="rounded-sm p-7"
            style={{ background: "#1a2535" }}
          >
            <p className="text-[10px] tracking-[0.18em] uppercase text-[var(--ink-40)] mb-3">
              The result
            </p>
            <p
              className="font-condensed font-semibold text-ink leading-snug"
              style={{ fontSize: "clamp(17px, 2vw, 22px)" }}
            >
              {c.result}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function Cases() {
  const sectionRef = useRef<HTMLElement>(null);
  const headRef    = useRef<HTMLDivElement>(null);

  useEffect(() => {
    gsap.registerPlugin(ScrollTrigger);
    if (!headRef.current) return;
    revealUp(headRef.current.querySelectorAll(".rv"), {
      trigger: headRef.current,
      stagger: 0.1,
    });
  }, []);

  return (
    <section
      ref={sectionRef}
      id="cases"
      className="relative z-10"
      style={{ background: "#f2f3f5", padding: "140px 64px" }}
    >
      <div className="max-content">
        <div className="sec-label mb-14 text-[#0c1521]/40">
          <span>05</span>
          <span className="ml-3">Selected work</span>
        </div>

        <div ref={headRef} className="grid lg:grid-cols-2 gap-16 mb-16">
          <h2
            className="rv font-condensed font-bold text-[#0c1521] leading-[0.95]"
            style={{ fontSize: "clamp(38px, 5vw, 72px)", letterSpacing: "-0.02em" }}
          >
            Work that changed how brands are{" "}
            <em className="not-italic" style={{ color: "var(--cr)" }}>understood.</em>
          </h2>
          <p
            className="rv font-light text-[#0c1521]/50 leading-relaxed self-end"
            style={{ fontSize: "18px", maxWidth: "400px" }}
          >
            Branding, retail, nonprofit, fitness and community — every project
            starts with the same question: does this brand actually connect?
          </p>
        </div>

        {/* Cases table */}
        <div className="border-t border-[#0c1521]/10">
          {cases.map((c, i) => (
            <CaseRow key={c.id} c={c} index={i} />
          ))}
        </div>

        <div className="mt-8 text-right">
          <a
            href="https://germanbaher.myportfolio.com/work"
            target="_blank"
            rel="noopener noreferrer"
            className="text-[11px] tracking-[0.16em] uppercase no-underline
              border-b border-[var(--cr)]/25 pb-0.5 text-[var(--cr)]/50
              hover:text-[var(--cr)] hover:border-[var(--cr)] transition-colors duration-300"
          >
            View full portfolio →
          </a>
        </div>
      </div>
    </section>
  );
}
