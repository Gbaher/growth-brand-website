"use client";
import { useEffect, useRef } from "react";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { splitTextNodes } from "@/lib/splitWords";
import { parallaxBg, prefersReducedMotion } from "@/lib/animations";

export default function Hero() {
  const sectionRef  = useRef<HTMLElement>(null);
  const bgRef       = useRef<HTMLDivElement>(null);
  const eyebrowRef  = useRef<HTMLDivElement>(null);
  const h1Ref       = useRef<HTMLHeadingElement>(null);
  const subRef      = useRef<HTMLParagraphElement>(null);
  const ctasRef     = useRef<HTMLDivElement>(null);
  const footerRef   = useRef<HTMLDivElement>(null);
  const scrollHint  = useRef<HTMLDivElement>(null);

  useEffect(() => {
    gsap.registerPlugin(ScrollTrigger);
    if (!sectionRef.current) return;

    // ── Split headline into words ──
    if (h1Ref.current) splitTextNodes(h1Ref.current);

    const reduced = prefersReducedMotion();

    // ── Entrance timeline ──
    const tl = gsap.timeline({ delay: 0.2 });

    if (!reduced) {
      // Crimson top rule
      tl.fromTo(
        sectionRef.current.querySelector(".hero-rule"),
        { scaleX: 0 },
        { scaleX: 1, duration: 1.3, ease: "power3.out", transformOrigin: "left" }
      );

      // Eyebrow
      tl.fromTo(
        eyebrowRef.current,
        { opacity: 0, y: 16 },
        { opacity: 1, y: 0, duration: 0.7, ease: "power3.out" },
        "-=0.8"
      );

      // Words stagger
      if (h1Ref.current) {
        tl.fromTo(
          h1Ref.current.querySelectorAll(".word"),
          { opacity: 0, yPercent: 110 },
          { opacity: 1, yPercent: 0, duration: 0.85, stagger: 0.055, ease: "power3.out" },
          "-=0.5"
        );
      }

      // Sub + CTAs
      tl.fromTo(
        [subRef.current, ctasRef.current],
        { opacity: 0, y: 24 },
        { opacity: 1, y: 0, duration: 0.8, stagger: 0.15, ease: "power3.out" },
        "-=0.4"
      );

      // Footer row
      tl.fromTo(
        footerRef.current,
        { opacity: 0 },
        { opacity: 1, duration: 0.8, ease: "power2.out" },
        "-=0.4"
      );

      // Scroll hint bounce (separate, delayed)
      gsap.fromTo(
        scrollHint.current,
        { opacity: 0, y: 6 },
        { opacity: 1, y: 0, duration: 0.6, delay: 2.4, ease: "power2.out" }
      );
    }

    // ── Parallax on bg ──
    if (bgRef.current && sectionRef.current && !reduced) {
      parallaxBg(bgRef.current, { trigger: sectionRef.current, yPercent: 22, scrub: 1.5 });
    }

    // ── Fade out on scroll exit ──
    if (!reduced) {
      gsap.to(sectionRef.current.querySelector(".hero-content"), {
        opacity: 0,
        y: -40,
        ease: "none",
        scrollTrigger: {
          trigger: sectionRef.current,
          start: "60% top",
          end: "bottom top",
          scrub: 0.8,
        },
      });
    }
  }, []);

  return (
    <section
      ref={sectionRef}
      id="hero"
      className="relative w-full overflow-hidden"
      style={{ height: "100svh" }}
    >
      {/* Crimson top rule */}
      <div
        className="hero-rule absolute top-0 left-0 right-0 h-px z-10"
        style={{ background: "var(--cr)" }}
      />

      {/* Background — deep dark with crimson gradient */}
      <div
        ref={bgRef}
        className="absolute inset-0 will-change-transform"
        style={{ top: "-20%", bottom: "-20%" }}
      >
        {/* CSS background — placeholder until real image is dropped in */}
        <div
          className="w-full h-full"
          style={{
            background: `
              radial-gradient(ellipse 80% 70% at 60% 40%, rgba(219,38,83,.06) 0%, transparent 65%),
              radial-gradient(ellipse 60% 50% at 20% 80%, rgba(12,21,33,.8) 0%, transparent 70%),
              linear-gradient(160deg, #050505 0%, #0a0c14 50%, #060a10 100%)
            `,
          }}
        />
        {/*
          TO ADD YOUR HERO IMAGE:
          Replace the div above with:
          <Image src="/assets/hero/hero-01.webp" alt="" fill className="object-cover" priority />
          And add overlay:
          <div className="absolute inset-0 bg-black/72" />
        */}
      </div>

      {/* Ghost large italic text */}
      <div
        className="absolute right-0 top-1/2 -translate-y-1/2 pointer-events-none select-none"
        aria-hidden
      >
        <span
          className="font-condensed font-bold italic text-transparent leading-none"
          style={{
            fontSize: "clamp(140px, 24vw, 320px)",
            WebkitTextStroke: "0.5px rgba(52,69,96,0.25)",
            letterSpacing: "-0.03em",
          }}
        >
          BRAND
        </span>
      </div>

      {/* Content */}
      <div
        className="hero-content relative z-10 h-full flex flex-col justify-end"
        style={{ padding: "0 64px 80px" }}
      >
        {/* Eyebrow */}
        <div ref={eyebrowRef} className="eyebrow mb-7 opacity-0">
          Branding Consultant · Ottawa · Growth Brands
        </div>

        {/* Headline */}
        <h1
          ref={h1Ref}
          className="font-condensed font-bold leading-[0.92] text-ink"
          style={{
            fontSize: "clamp(56px, 9.5vw, 132px)",
            letterSpacing: "-0.025em",
            maxWidth: "900px",
          }}
        >
          Creativity,{" "}
          <em className="not-italic" style={{ color: "var(--cr)" }}>strategy</em>{" "}
          and design for brands that want to{" "}
          <em className="italic" style={{ color: "var(--cr)" }}>connect.</em>
        </h1>

        {/* Sub */}
        <p
          ref={subRef}
          className="opacity-0 mt-5 font-light text-[var(--ink-60)] leading-relaxed"
          style={{ fontSize: "clamp(16px, 1.4vw, 20px)", maxWidth: "480px" }}
        >
          I build brands from the inside out — clarity before aesthetics,
          strategy before execution.
        </p>

        {/* CTAs */}
        <div ref={ctasRef} className="opacity-0 flex flex-wrap gap-4 mt-9">
          <a href="#cta"         className="btn-primary">Book a Brand Diagnosis →</a>
          <a href="#methodology" className="btn-outline">Discover the method</a>
        </div>
      </div>

      {/* Footer rule + meta */}
      <div
        ref={footerRef}
        className="opacity-0 absolute bottom-0 left-0 right-0 z-10 flex items-center
          justify-between border-t border-white/[0.08]"
        style={{ padding: "16px 64px" }}
      >
        <span className="text-[9px] tracking-[0.22em] uppercase text-[var(--ink-40)]">
          Feeling · Doing · Thinking
        </span>
        <div ref={scrollHint} className="flex items-center gap-3 opacity-0">
          <span className="text-[9px] tracking-[0.2em] uppercase text-[var(--ink-40)]">Scroll</span>
          <div className="w-8 h-px bg-white/15 relative overflow-hidden">
            <div
              className="absolute inset-0 bg-[var(--cr)]"
              style={{ animation: "scrollPulse 2.4s ease-in-out 0.5s infinite" }}
            />
          </div>
        </div>
        <span className="text-[9px] tracking-[0.22em] uppercase text-[var(--ink-40)]">
          germanbaher.com
        </span>
      </div>

      <style jsx>{`
        @keyframes scrollPulse {
          0%   { transform: translateX(-101%); }
          50%  { transform: translateX(0); }
          100% { transform: translateX(101%); }
        }
      `}</style>
    </section>
  );
}
