"use client";
import { useEffect, useRef } from "react";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { revealUp, prefersReducedMotion } from "@/lib/animations";

const pillars = [
  {
    num:    "01",
    name:   "Feeling",
    em:     "Emotional connection",
    q:      "What does your brand make people feel?",
    body:   "Emotion. Purpose. Meaning. Without this layer, brands become interchangeable. Feeling is the foundation that makes everything else matter — it's the reason someone chooses you over a competitor with similar features.",
    icon: (
      <svg width="44" height="44" viewBox="0 0 44 44" fill="none">
        <circle cx="22" cy="22" r="21" stroke="#ee2551" strokeWidth="0.8" />
        <path d="M22 32s-10-6-10-12.5A6 6 0 0 1 22 15.3 6 6 0 0 1 32 19.5C32 26 22 32 22 32z"
          stroke="#ee2551" strokeWidth="1" fill="none" />
      </svg>
    ),
  },
  {
    num:    "02",
    name:   "Doing",
    em:     "Consistent behavior",
    q:      "How does your brand behave across every touchpoint?",
    body:   "Strategy without execution is fiction. Doing maps the gap between what a brand promises and how it actually shows up — in retail, in content, in service, in every micro-interaction that shapes perception.",
    icon: (
      <svg width="44" height="44" viewBox="0 0 44 44" fill="none">
        <circle cx="22" cy="22" r="21" stroke="#ee2551" strokeWidth="0.8" />
        <circle cx="22" cy="17" r="5" stroke="#ee2551" strokeWidth="1" fill="none" />
        <path d="M12 34c0-5.5 4.5-9 10-9s10 3.5 10 9"
          stroke="#ee2551" strokeWidth="1" strokeLinecap="round" fill="none" />
      </svg>
    ),
  },
  {
    num:    "03",
    name:   "Thinking",
    em:     "Strategic clarity",
    q:      "What strategic clarity guides your every decision?",
    body:   "When a brand knows what it believes — not just what it sells — communication becomes consistent, intentional and magnetic. Thinking is the lens that gives all decisions coherence and direction.",
    icon: (
      <svg width="44" height="44" viewBox="0 0 44 44" fill="none">
        <circle cx="22" cy="22" r="21" stroke="#ee2551" strokeWidth="0.8" />
        <circle cx="22" cy="19" r="7" stroke="#ee2551" strokeWidth="1" fill="none" />
        <path d="M18 26v5M26 26v5M18 31h8"
          stroke="#ee2551" strokeWidth="1" strokeLinecap="round" />
      </svg>
    ),
  },
];

export default function Methodology() {
  const sectionRef  = useRef<HTMLElement>(null);
  const wrapRef     = useRef<HTMLDivElement>(null);
  const leftRef     = useRef<HTMLDivElement>(null);
  const pillarsRef  = useRef<(HTMLDivElement | null)[]>([]);

  useEffect(() => {
    gsap.registerPlugin(ScrollTrigger);
    const section = sectionRef.current;
    if (!section) return;

    const reduced = prefersReducedMotion();
    if (reduced) return;

    // Left col reveal
    revealUp(leftRef.current!.querySelectorAll(".rv"), {
      trigger: leftRef.current!,
      stagger: 0.12,
      start: "top 78%",
    });

    // Each pillar enters on scroll
    pillarsRef.current.forEach((pillar, i) => {
      if (!pillar) return;
      gsap.fromTo(
        pillar,
        { opacity: 0, x: 32 },
        {
          opacity: 1,
          x: 0,
          duration: 0.85,
          delay: i * 0.08,
          ease: "power3.out",
          scrollTrigger: {
            trigger: pillar,
            start: "top 84%",
            toggleActions: "play none none reverse",
          },
        }
      );
    });

    // Number counters fade in with parallax offset
    pillarsRef.current.forEach((pillar) => {
      if (!pillar) return;
      gsap.fromTo(
        pillar.querySelector(".pillar-num"),
        { opacity: 0.06 },
        {
          opacity: 0.18,
          ease: "none",
          scrollTrigger: {
            trigger: pillar,
            start: "top bottom",
            end: "bottom top",
            scrub: 1,
          },
        }
      );
    });
  }, []);

  return (
    <section
      ref={sectionRef}
      id="methodology"
      className="relative z-10"
      style={{ background: "#1a2535", padding: "140px 64px" }}
    >
      {/* Subtle grid texture */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          backgroundImage: `
            linear-gradient(rgba(52,69,96,.18) 1px, transparent 1px),
            linear-gradient(90deg, rgba(52,69,96,.18) 1px, transparent 1px)
          `,
          backgroundSize: "64px 64px",
        }}
      />

      <div className="max-content relative z-10">
        <div className="sec-label mb-14">
          <span>04</span>
          <span className="ml-3">The methodology</span>
        </div>

        <div ref={wrapRef} className="grid lg:grid-cols-2 gap-24 items-start">
          {/* Left */}
          <div ref={leftRef}>
            <h2
              className="rv font-condensed font-bold text-ink leading-[0.94]"
              style={{
                fontSize: "clamp(48px, 7vw, 96px)",
                letterSpacing: "-0.025em",
              }}
            >
              Feeling.
              <br />
              Doing.
              <br />
              <em className="italic" style={{ color: "var(--cr)" }}>Thinking.</em>
            </h2>

            <p
              className="rv mt-9 font-light leading-relaxed text-[var(--ink-60)]"
              style={{
                fontSize: "19px",
                borderLeft: "1.5px solid var(--cr)",
                paddingLeft: "20px",
                maxWidth: "420px",
              }}
            >
              A proprietary methodology that brings human logic back to branding.
              When these three elements align, brands stop pushing messages and
              start building relationships.
            </p>

            {/* FDT result card */}
            <div
              className="rv mt-10 p-6 rounded-sm border border-[var(--border)]"
              style={{ background: "#243045" }}
            >
              <p className="text-[10px] tracking-[0.22em] uppercase text-[var(--ink-40)] mb-4">
                The outcome
              </p>
              <p
                className="font-condensed font-semibold text-ink leading-snug"
                style={{ fontSize: "clamp(16px, 2vw, 22px)" }}
              >
                "When these three elements align, brands stop pushing messages and
                start{" "}
                <em className="not-italic" style={{ color: "var(--cr)" }}>
                  building relationships.
                </em>"
              </p>
              <div className="mt-6 flex gap-8 flex-wrap">
                {["Redefine positioning", "Transform identity", "Align strategy"].map((t) => (
                  <div key={t} className="flex flex-col gap-1.5">
                    <div className="w-3 h-px bg-[var(--cr)]" />
                    <span className="text-[10px] tracking-wider uppercase text-[var(--ink-40)]">{t}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Right — pillars */}
          <div className="flex flex-col gap-0">
            {pillars.map((p, i) => (
              <div
                key={p.name}
                ref={(el) => { pillarsRef.current[i] = el; }}
                className="py-8 border-b border-[var(--border)] group hover:bg-white/[0.02]
                  transition-colors duration-500"
                style={{ borderTop: i === 0 ? "0.5px solid var(--border)" : undefined }}
              >
                <div className="flex gap-5 items-start">
                  {/* Icon */}
                  <div className="flex-shrink-0 mt-1">{p.icon}</div>

                  <div className="flex-1">
                    <div className="flex items-baseline gap-4 mb-1">
                      <span
                        className="pillar-num font-condensed font-bold leading-none"
                        style={{ fontSize: "40px", color: "rgba(238,37,81,0.1)" }}
                      >
                        {p.num}
                      </span>
                      <h3
                        className="font-condensed font-bold text-ink"
                        style={{ fontSize: "clamp(24px, 2.8vw, 32px)", letterSpacing: "-0.01em" }}
                      >
                        {p.name}
                      </h3>
                    </div>
                    <p
                      className="font-sans text-[12px] font-light italic mb-3"
                      style={{ color: "var(--cr)" }}
                    >
                      {p.q}
                    </p>
                    <p
                      className="font-light leading-relaxed text-[var(--ink-60)]"
                      style={{ fontSize: "17px" }}
                    >
                      {p.body}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
