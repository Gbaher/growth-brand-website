"use client";
import { useEffect, useRef } from "react";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { revealUp, revealWords, prefersReducedMotion } from "@/lib/animations";
import { splitTextNodes } from "@/lib/splitWords";

const pains = [
  {
    n: "01",
    title: "They look good but don't connect.",
    body: "Design without strategy creates beautiful noise. The audience sees the brand but doesn't feel it.",
  },
  {
    n: "02",
    title: "Too many channels, no clear message.",
    body: "Every platform demands attention. None drives coherent results. The message fragments.",
  },
  {
    n: "03",
    title: "Teams move fast in different directions.",
    body: "Without a strategic core, execution accelerates the confusion. Momentum without clarity.",
  },
  {
    n: "04",
    title: "More content, same stagnation.",
    body: "Output increases. Connection doesn't. The brand becomes background noise in its own category.",
  },
];

export default function Problem() {
  const sectionRef = useRef<HTMLElement>(null);
  const h2Ref      = useRef<HTMLHeadingElement>(null);
  const itemsRef   = useRef<HTMLDivElement>(null);
  const conclusionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    gsap.registerPlugin(ScrollTrigger);
    const section = sectionRef.current;
    if (!section) return;

    if (h2Ref.current) splitTextNodes(h2Ref.current);

    const reduced = prefersReducedMotion();
    if (reduced) return;

    // Headline words
    revealWords(h2Ref.current!, { trigger: section, stagger: 0.055 });

    // Pain items stagger
    if (itemsRef.current) {
      revealUp(itemsRef.current.querySelectorAll(".pain-item"), {
        trigger: itemsRef.current,
        stagger: 0.12,
        start: "top 80%",
      });
    }

    // Conclusion block
    if (conclusionRef.current) {
      revealUp(conclusionRef.current, { trigger: conclusionRef.current, start: "top 85%" });
    }
  }, []);

  return (
    <section
      ref={sectionRef}
      id="problem"
      className="relative z-10 bg-[#f2f3f5]"
      style={{ padding: "140px 64px" }}
    >
      <div className="max-content">
        {/* Section label */}
        <div className="sec-label mb-14 text-[#0c1521]/40">
          <span>02</span>
          <span className="ml-3">The problem</span>
        </div>

        {/* Two-column */}
        <div className="grid lg:grid-cols-2 gap-20 items-start">
          {/* Left — headline */}
          <div>
            <h2
              ref={h2Ref}
              className="font-condensed font-bold leading-[0.95] text-[#0c1521]"
              style={{ fontSize: "clamp(40px, 5.5vw, 76px)", letterSpacing: "-0.02em" }}
            >
              Brands look good.{" "}
              <em className="not-italic" style={{ color: "var(--cr)" }}>
                But they don't connect.
              </em>
            </h2>
            <p
              className="mt-8 font-light leading-relaxed text-[#0c1521]/55"
              style={{ fontSize: "18px", maxWidth: "420px" }}
            >
              Most brand problems are not design problems. They are clarity problems.
              And clarity can only come from strategy — not from more content, better
              colors, or a new logo.
            </p>

            {/* Pull quote */}
            <div
              ref={conclusionRef}
              className="mt-10 p-7 rounded-sm"
              style={{ background: "#0c1521", borderLeft: "2px solid var(--cr)" }}
            >
              <p
                className="font-condensed font-semibold text-ink leading-snug"
                style={{ fontSize: "clamp(18px, 2.2vw, 24px)" }}
              >
                "Without strategic clarity, brands create noise instead of connection."
              </p>
              <p className="mt-3 text-[13px] text-[var(--ink-40)] font-light">
                — The most common outcome of brand ambiguity
              </p>
            </div>
          </div>

          {/* Right — pain items */}
          <div ref={itemsRef} className="flex flex-col">
            {pains.map((p, i) => (
              <div
                key={p.n}
                className="pain-item py-7 border-b border-[#0c1521]/10 grid gap-5"
                style={{ gridTemplateColumns: "36px 1fr" }}
              >
                <span
                  className="font-condensed font-bold text-3xl leading-none pt-1"
                  style={{ color: "rgba(238,37,81,0.12)" }}
                >
                  {p.n}
                </span>
                <div>
                  <h3
                    className="font-condensed font-bold text-[#0c1521] mb-2"
                    style={{ fontSize: "20px" }}
                  >
                    {p.title}
                  </h3>
                  <p className="font-light text-[#0c1521]/50 leading-relaxed" style={{ fontSize: "17px" }}>
                    {p.body}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
