"use client";
import { useEffect, useRef } from "react";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { revealUp, prefersReducedMotion } from "@/lib/animations";

const steps = [
  {
    n:     "01",
    title: "Brand Diagnosis",
    sub:   "Where does your brand actually stand?",
    body:  "A structured 30-minute session to map your brand's current state: clarity gaps, positioning tensions, communication inconsistencies. No assumptions. Only evidence.",
    duration: "30 min",
  },
  {
    n:     "02",
    title: "Brand Strategy",
    sub:   "The decisions that guide everything else.",
    body:  "Positioning, purpose, architecture and competitive differentiation. We define what your brand believes, who it's for, and why it exists — before any visual decision is made.",
    duration: "2–4 weeks",
  },
  {
    n:     "03",
    title: "Visual Identity System",
    sub:   "A coherent language, not just a logo.",
    body:  "Logo system, typography, color, layout principles, motion and usage guidelines. A full identity system that scales across every touchpoint and maintains coherence over time.",
    duration: "3–5 weeks",
  },
  {
    n:     "04",
    title: "Guided Implementation",
    sub:   "Execution aligned with the strategy.",
    body:  "From retail environments to digital platforms — guided rollout ensures the identity system is applied correctly and consistently. Strategy and design stay aligned through execution.",
    duration: "Ongoing",
  },
];

export default function Process() {
  const sectionRef  = useRef<HTMLElement>(null);
  const stepsRef    = useRef<(HTMLDivElement | null)[]>([]);
  const headRef     = useRef<HTMLDivElement>(null);
  const lineRef     = useRef<HTMLDivElement>(null);

  useEffect(() => {
    gsap.registerPlugin(ScrollTrigger);
    const section = sectionRef.current;
    if (!section) return;

    const reduced = prefersReducedMotion();

    // Head reveal
    if (headRef.current && !reduced) {
      revealUp(headRef.current.querySelectorAll(".rv"), {
        trigger: headRef.current,
        stagger: 0.1,
      });
    }

    // Progress line animation
    if (lineRef.current && !reduced) {
      gsap.fromTo(
        lineRef.current,
        { scaleY: 0 },
        {
          scaleY: 1,
          ease: "none",
          transformOrigin: "top",
          scrollTrigger: {
            trigger: section,
            start: "top 80%",
            end: "bottom 80%",
            scrub: 1,
          },
        }
      );
    }

    // Each step reveals
    stepsRef.current.forEach((step, i) => {
      if (!step || reduced) return;
      gsap.fromTo(
        step,
        { opacity: 0, x: 40 },
        {
          opacity: 1,
          x: 0,
          duration: 0.85,
          ease: "power3.out",
          scrollTrigger: {
            trigger: step,
            start: "top 82%",
            toggleActions: "play none none reverse",
          },
        }
      );

      // Step number grows on scroll
      gsap.fromTo(
        step.querySelector(".step-num"),
        { opacity: 0.08, scale: 0.9 },
        {
          opacity: 0.2,
          scale: 1,
          ease: "none",
          scrollTrigger: {
            trigger: step,
            start: "top 80%",
            end: "top 30%",
            scrub: 1.2,
          },
        }
      );
    });
  }, []);

  return (
    <section
      ref={sectionRef}
      id="process"
      className="relative z-10"
      style={{ background: "#0c1521", padding: "140px 64px" }}
    >
      <div className="max-content">
        <div className="sec-label mb-14">
          <span>06</span>
          <span className="ml-3">The process</span>
        </div>

        <div ref={headRef} className="grid lg:grid-cols-2 gap-16 mb-20">
          <h2
            className="rv font-condensed font-bold text-ink leading-[0.95]"
            style={{ fontSize: "clamp(38px, 5.5vw, 76px)", letterSpacing: "-0.02em" }}
          >
            Four stages.
            <br />
            <em className="italic" style={{ color: "var(--cr)" }}>One direction.</em>
          </h2>
          <p
            className="rv font-light text-[var(--ink-60)] leading-relaxed self-end"
            style={{ fontSize: "18px", maxWidth: "420px" }}
          >
            A structured engagement designed to deliver clarity at every phase —
            from diagnosis to full implementation. Every step builds on the last.
          </p>
        </div>

        {/* Steps — vertical timeline */}
        <div className="relative pl-[72px] md:pl-[96px]">
          {/* Vertical progress line */}
          <div
            className="absolute left-[22px] md:left-[28px] top-4 bottom-4 w-px"
            style={{ background: "rgba(238,37,81,.12)" }}
          >
            <div
              ref={lineRef}
              className="absolute inset-0 origin-top"
              style={{ background: "var(--cr)", scaleY: 0 } as React.CSSProperties}
            />
          </div>

          <div className="flex flex-col gap-0">
            {steps.map((s, i) => (
              <div
                key={s.n}
                ref={(el) => { stepsRef.current[i] = el; }}
                className="relative pb-14"
              >
                {/* Dot on line */}
                <div
                  className="absolute flex items-center justify-center"
                  style={{ left: "-70px", top: "6px", width: "40px", height: "40px" }}
                >
                  <div
                    className="w-2 h-2 rounded-full"
                    style={{ background: "var(--cr)" }}
                  />
                </div>

                {/* Number + duration row */}
                <div className="flex items-center gap-5 mb-4">
                  <span
                    className="step-num font-condensed font-bold leading-none"
                    style={{
                      fontSize: "clamp(52px, 7vw, 80px)",
                      letterSpacing: "-0.03em",
                      color: "rgba(238,37,81,.1)",
                    }}
                  >
                    {s.n}
                  </span>
                  <span
                    className="text-[10px] tracking-[0.2em] uppercase px-3 py-1 rounded-sm"
                    style={{
                      color: "var(--cr)",
                      background: "rgba(238,37,81,.08)",
                      border: "0.5px solid rgba(238,37,81,.2)",
                    }}
                  >
                    {s.duration}
                  </span>
                </div>

                {/* Content */}
                <h3
                  className="font-condensed font-bold text-ink mb-2"
                  style={{ fontSize: "clamp(22px, 2.8vw, 34px)", letterSpacing: "-0.01em" }}
                >
                  {s.title}
                </h3>
                <p
                  className="font-sans text-[12px] italic mb-4"
                  style={{ color: "var(--cr)" }}
                >
                  {s.sub}
                </p>
                <p
                  className="font-light text-[var(--ink-60)] leading-relaxed"
                  style={{ fontSize: "18px", maxWidth: "620px" }}
                >
                  {s.body}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
