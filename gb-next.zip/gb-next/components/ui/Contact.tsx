"use client";
import { useEffect, useRef } from "react";
import { revealUp } from "@/lib/animations";

const contacts = [
  { label: "Phone",     value: "+1 343 988 4177",                    href: "tel:+13439884177" },
  { label: "Portfolio", value: "germanbaher.myportfolio.com",        href: "https://germanbaher.myportfolio.com/work" },
  { label: "LinkedIn",  value: "linkedin.com/in/germanbaher",        href: "https://www.linkedin.com/in/germanbaher/" },
  { label: "Email",     value: "hola@germanbaher.com",               href: "mailto:hola@germanbaher.com" },
];

export default function Contact() {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!ref.current) return;
    revealUp(ref.current.querySelectorAll(".col"), { trigger: ref.current, stagger: 0.1 });
  }, []);

  return (
    <div
      ref={ref}
      className="relative z-10 border-t"
      style={{ padding: "72px 64px", borderColor: "rgba(238,37,81,.08)" }}
    >
      <div
        className="max-content grid gap-10"
        style={{ gridTemplateColumns: "repeat(auto-fit, minmax(160px, 1fr))" }}
      >
        {contacts.map((c) => (
          <div key={c.label} className="col">
            <div
              className="text-[10px] tracking-[0.2em] uppercase mb-2.5"
              style={{ color: "rgba(238,37,81,.38)" }}
            >
              {c.label}
            </div>
            <a
              href={c.href}
              target={c.href.startsWith("http") ? "_blank" : undefined}
              rel="noopener noreferrer"
              className="font-condensed font-normal no-underline leading-snug block
                transition-colors duration-300 hover:text-[var(--cr)]"
              style={{ fontSize: "17px", color: "rgba(232,234,237,.5)" }}
            >
              {c.value}
            </a>
          </div>
        ))}
      </div>
    </div>
  );
}
