"use client";
import { useEffect, useRef } from "react";
import { gsap } from "gsap";
import { prefersReducedMotion } from "@/lib/animations";

const items = [
  "Brand Strategy",
  "Visual Identity",
  "Feeling Doing Thinking",
  "Retail Branding",
  "Digital Funnels",
  "AI Creative Direction",
  "Growth Brands",
  "Ottawa · Bolivia · LATAM",
];

export default function Marquee() {
  const trackRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const track = trackRef.current;
    if (!track || prefersReducedMotion()) return;

    const w = track.scrollWidth / 2;
    gsap.to(track, {
      x: -w,
      ease: "none",
      duration: w / 70,
      repeat: -1,
    });
  }, []);

  const duped = [...items, ...items]; // duplicate for seamless loop

  return (
    <div
      className="relative z-10 overflow-hidden border-y"
      style={{
        padding: "20px 0",
        borderColor: "rgba(238,37,81,.08)",
        background: "rgba(0,0,0,.3)",
      }}
    >
      <div ref={trackRef} className="flex will-change-transform">
        {duped.map((item, i) => (
          <div
            key={i}
            className="flex items-center gap-8 px-8 flex-shrink-0"
          >
            <span
              className="font-condensed font-bold uppercase whitespace-nowrap"
              style={{
                fontSize: "clamp(14px, 1.8vw, 22px)",
                color: "rgba(232,234,237,.07)",
                letterSpacing: "-0.01em",
              }}
            >
              {item}
            </span>
            <span style={{ color: "var(--cr)", fontSize: "0.6em" }}>·</span>
          </div>
        ))}
      </div>
    </div>
  );
}
