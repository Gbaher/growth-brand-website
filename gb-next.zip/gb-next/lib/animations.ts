"use client";

// Centralized GSAP helpers.
// All animations check prefers-reduced-motion before running.

import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

if (typeof window !== "undefined") {
  gsap.registerPlugin(ScrollTrigger);
}

export const prefersReducedMotion = () =>
  typeof window !== "undefined" &&
  window.matchMedia("(prefers-reduced-motion: reduce)").matches;

// ── Reveal helpers ────────────────────────────────────

/** Fade + translateY reveal on scroll enter */
export function revealUp(
  targets: gsap.TweenTarget,
  options: {
    trigger?: Element | string;
    delay?: number;
    stagger?: number;
    duration?: number;
    start?: string;
    scrub?: boolean | number;
    onComplete?: () => void;
  } = {}
) {
  if (prefersReducedMotion()) {
    gsap.set(targets, { opacity: 1, y: 0 });
    return;
  }
  const {
    trigger,
    delay = 0,
    stagger = 0,
    duration = 0.9,
    start = "top 82%",
    scrub = false,
    onComplete,
  } = options;

  gsap.fromTo(
    targets,
    { opacity: 0, y: 36 },
    {
      opacity: 1,
      y: 0,
      duration,
      delay,
      stagger,
      ease: "power3.out",
      onComplete,
      scrollTrigger: trigger
        ? { trigger, start, toggleActions: "play none none reverse" }
        : undefined,
    }
  );
}

/** Fade only */
export function revealFade(
  targets: gsap.TweenTarget,
  options: {
    trigger?: Element | string;
    delay?: number;
    duration?: number;
    start?: string;
  } = {}
) {
  if (prefersReducedMotion()) {
    gsap.set(targets, { opacity: 1 });
    return;
  }
  const { trigger, delay = 0, duration = 1, start = "top 85%" } = options;

  gsap.fromTo(
    targets,
    { opacity: 0 },
    {
      opacity: 1,
      duration,
      delay,
      ease: "power2.out",
      scrollTrigger: trigger
        ? { trigger, start, toggleActions: "play none none reverse" }
        : undefined,
    }
  );
}

/** Split headline — each word reveals from below */
export function revealWords(
  container: Element,
  options: {
    trigger?: Element | string;
    stagger?: number;
    duration?: number;
    start?: string;
  } = {}
) {
  if (prefersReducedMotion()) {
    gsap.set(container.querySelectorAll(".word"), { opacity: 1, yPercent: 0 });
    return;
  }
  const { trigger, stagger = 0.06, duration = 0.85, start = "top 80%" } = options;

  gsap.fromTo(
    container.querySelectorAll(".word"),
    { opacity: 0, yPercent: 110 },
    {
      opacity: 1,
      yPercent: 0,
      duration,
      stagger,
      ease: "power3.out",
      scrollTrigger: trigger
        ? { trigger: trigger ?? container, start, toggleActions: "play none none reverse" }
        : undefined,
    }
  );
}

/** Parallax on a background element */
export function parallaxBg(
  target: Element,
  {
    trigger,
    yPercent = 20,
    scrub = 1.2,
  }: { trigger: Element; yPercent?: number; scrub?: number }
) {
  if (prefersReducedMotion()) return;

  gsap.fromTo(
    target,
    { yPercent: -yPercent / 2 },
    {
      yPercent: yPercent / 2,
      ease: "none",
      scrollTrigger: {
        trigger,
        start: "top bottom",
        end: "bottom top",
        scrub,
      },
    }
  );
}

/** Pinned section — content reveals sequentially while pinned */
export function pinnedSection(
  trigger: Element,
  panels: Element[],
  {
    pinSpacing = true,
    scrub = true,
  }: { pinSpacing?: boolean; scrub?: boolean | number } = {}
) {
  if (prefersReducedMotion()) {
    panels.forEach((p) => gsap.set(p, { opacity: 1, y: 0 }));
    return;
  }

  const tl = gsap.timeline({
    scrollTrigger: {
      trigger,
      start: "top top",
      end: `+=${panels.length * 400}`,
      pin: true,
      pinSpacing,
      scrub: scrub === true ? 1 : scrub,
      anticipatePin: 1,
    },
  });

  panels.forEach((panel, i) => {
    if (i === 0) {
      tl.fromTo(panel, { opacity: 0, y: 30 }, { opacity: 1, y: 0, duration: 0.4 });
    } else {
      tl.fromTo(panel, { opacity: 0, y: 30 }, { opacity: 1, y: 0, duration: 0.4 }, `>${0.1}`);
    }
  });

  return tl;
}

/** Horizontal marquee scroll-linked */
export function scrollMarquee(
  track: Element,
  { direction = -1, speed = 80 }: { direction?: number; speed?: number } = {}
) {
  if (prefersReducedMotion()) return;
  const w = (track as HTMLElement).scrollWidth / 2;
  gsap.to(track, {
    x: direction * w,
    ease: "none",
    duration: w / speed,
    repeat: -1,
    modifiers: {
      x: gsap.utils.unitize((x) => parseFloat(x) % w),
    },
  });
}
