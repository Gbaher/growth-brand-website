"use client";

/**
 * Splits text content into individual <span class="word"> elements.
 * Used with revealWords() to animate word-by-word.
 *
 * Usage:
 *   <h1 ref={ref} data-split>Your headline text here</h1>
 *
 * After splitWords(ref.current):
 *   <h1><span class="word-wrap"><span class="word">Your</span></span> ...</h1>
 */
export function splitWords(el: HTMLElement): void {
  const text = el.textContent ?? "";
  const words = text.split(/(\s+)/);

  el.innerHTML = words
    .map((token) => {
      if (/^\s+$/.test(token)) return token; // preserve whitespace
      return `<span class="word-wrap" style="display:inline-block;overflow:hidden;vertical-align:top;"><span class="word" style="display:inline-block;">${token}</span></span>`;
    })
    .join("");
}

/**
 * Same as splitWords but preserves em/strong children.
 * Iterates text nodes only.
 */
export function splitTextNodes(el: HTMLElement): void {
  const walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT);
  const textNodes: Text[] = [];
  let node;
  while ((node = walker.nextNode())) textNodes.push(node as Text);

  textNodes.forEach((tn) => {
    const words = tn.textContent?.split(/(\s+)/) ?? [];
    const frag = document.createDocumentFragment();
    words.forEach((token) => {
      if (/^\s+$/.test(token)) {
        frag.appendChild(document.createTextNode(token));
      } else {
        const wrap = document.createElement("span");
        wrap.className = "word-wrap";
        wrap.style.cssText = "display:inline-block;overflow:hidden;vertical-align:top;";
        const inner = document.createElement("span");
        inner.className = "word";
        inner.style.cssText = "display:inline-block;";
        inner.textContent = token;
        wrap.appendChild(inner);
        frag.appendChild(wrap);
      }
    });
    tn.parentNode?.replaceChild(frag, tn);
  });
}
