import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./app/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        cr:  "#ee2551",
        cr2: "#db2653",
        ink: "#e8eaed",
      },
      fontFamily: {
        condensed: ["var(--font-condensed)"],
        sans:      ["var(--font-sans)"],
      },
      // Custom screen for large displays
      screens: {
        "2xl": "1440px",
      },
    },
  },
  plugins: [],
};

export default config;
